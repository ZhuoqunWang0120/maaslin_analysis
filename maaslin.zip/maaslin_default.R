#!/usr/bin/env Rscript

library(Maaslin2)

rm(list = ls())
ps = readRDS("ps_otu_100.rds")
input_data = data.frame(otu_table(ps)) # taxa are columns
covariates = c("Case_Control", "post_seroconversion", "Age_at_Collection", "Country", "Gender",
"BF", "Solid_Food", "Eggs", "Fish", "Soy_Prod", "Rye", "Barley", "Buckwheat_Millet")
# baseline = c("control",F,rep("false",length(dietcovariates)))
# covariate = "BF"
# formula = as.formula(paste0("~",covariate,"+log(Age_at_Collection)+Country+post_seroconversion+Gender+Case_Control+",paste(dietcovariates[-which(dietcovariates==covariate)],collapse = "+"),"+(1 | Subject_ID)"))
sample_data = data.frame(sample_data(ps))[,c(covariates, "Subject_ID")]
sample_data$log_age = log(sample_data$Age_at_Collection)
sample_data$Age_at_Collection = NULL

output_dir = "default_output"
fixed_effects = gsub("Age_at_Collection", "log_age", covariates)

test_fit = Maaslin2(input_data = input_data,
input_metadata = sample_data, 
output = output_dir, 
fixed_effects = fixed_effects,
random_effects = "Subject_ID")

signif = read.csv(paste0(output_dir, "/significant_results.tsv"), sep = "\t")
taxtab = data.frame(tax_table(ps))
taxtab$OTU = paste0("X", rownames(taxtab))
signif_taxa = merge(x = signif, y = taxtab, by.x = "feature", by.y = "OTU")
signif_taxa = signif_taxa[order(signif_taxa$metadata),]
write.csv(signif_taxa, paste0(output_dir, "/signif_taxa.csv"))
signif_otu = list()
for (x in fixed_effects){
    signif_otu[[x]] = signif_taxa[signif_taxa$metadata == x, ]
}

# visualization
library(ape)
source("~/LTN_04122022/LTN_analysis_revision_backup/LTN_analysis_revision/src/src/LTN/utils.R")

pdf(paste0(output_dir,"/pmap_qval.pdf"), width = 14)
for (x in fixed_effects){
    file = paste0("/Users/zhuoqunwang/LTN_curr/code_results/LTN_analysis_revision/results/application/pmap/", x, "_lambda10.RData")
    if (file.exists(file)){
        pmap = readRDS(file)
        tree = phy_tree(ps)
        # tip_label = sapply(paste0("X", tree$tip.label) %in% signif_otu[[x]], function(x){if(x){"o"}else{""}})
        tip_label = sapply(paste0("X", tree$tip.label), function(otu){
            if (!(otu %in% signif_otu[[x]]$feature)){
                return("")
            }
            else{
                qval = signif_otu[[x]][signif_otu[[x]]$feature==otu, "qval"]
                mark = ""
                if (qval < 0.25){
                    mark = paste0(mark, "*")
                }
                if (qval < 0.1){
                    mark = paste0(mark, "*")
                }
                if (qval < 0.05){
                    mark = paste0(mark, "*")
                }
                return(mark)
            }
        })
        plot_pmap(pmap, tree, main.text = x,label = NULL, tip_label = tip_label)
    }
}
dev.off()
