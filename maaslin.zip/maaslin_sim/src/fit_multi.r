library(Maaslin2)
input_data1 = readRDS("maaslin_sim/cache/cross_group_comparison/ps_sim_100.rds")
for (seed in 1:500){
    for (H in 0:1){
        cat("seed", seed, "H", H, "\n")
        input_data2 = readRDS(paste0("maaslin_sim/cache/cross_group_comparison/multi_otu/sim", seed, "H", H, ".rds"))
        cnt = input_data2$cnt
        Xtest = input_data2$Xtest
        Xadjust = input_data1$Xadjust[,2] # remove intercept since Maaslin will add intercept
        grouplabel = input_data1$grouplabel
        input_metadata = data.frame(Xtest = Xtest, Xadjust = Xadjust, randeff = as.factor(grouplabel)) 
        input_metadata$Xtest = as.factor(input_metadata$Xtest)
        rownames(input_metadata) = rownames(cnt)

        output_dir = paste0("maaslin_sim/cache/multi/sim",seed,"H",H)
        system(paste0("mkdir -p ", output_dir))
        test_fit1 = Maaslin2(input_data = cnt,
        input_metadata = input_metadata, 
        output = output_dir, 
        fixed_effects = c("Xtest", "Xadjust"),
        random_effects = "randeff",
        plot_heatmap = F,
        plot_scatter = F)
    }
}




