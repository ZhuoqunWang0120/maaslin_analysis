library(ROCR)

pdf('maaslin_sim/ROC.pdf', width = 8, height = 4)
par(mfrow = c(1,2))
for (a in 1:2){
scenario = c("single", "multi")[a]
cache_dir = paste0("maaslin_sim/cache/",scenario)
files = paste0(list.files(cache_dir, full.names = T), "/all_results.tsv")
files0 = grep("H0", files, val = T)
files1 = grep("H1", files, val = T)
t0 = - sapply(files0, function(x){
    if (file.exists(x)){
        res = read.csv(x,sep='\t')
        return(min(res[res$metadata == "Xtest", "qval"]))
    }
    else{return(NA)}
})
t1 = - sapply(files1, function(x){
    if (file.exists(x)){
        res = read.csv(x,sep='\t')
        return(min(res[res$metadata == "Xtest", "qval"]))
    }
    else{return(NA)}
})
t0 = na.omit(t0)
t1 = na.omit(t1)
labels = c(rep(0, length(t0)), rep(1, length(t1)))
roc = performance(prediction(c(t0, t1),labels),'tpr','fpr')
plot(roc, col = "#4b99ae", main = c('single OTU', 'multiple OTUs')[a])
ltn_res = readRDS(paste0("maaslin_sim/cache/other_results//", scenario, "_otu/LTN_sparse_lambda10.rds"))
dirfactor_roc2 = readRDS(paste0("maaslin_sim/cache/other_results//",scenario, "_otu/dirfactor_r2.rds"))
dirfactor_roc5 = readRDS(paste0("maaslin_sim/cache/other_results//",scenario, "_otu/dirfactor_r5.rds"))
plot(ltn_res, add = T, col = "black")
plot(dirfactor_roc2, add = T, col = "#e41a1c")
plot(dirfactor_roc5, add = T, col = "#48dc48")
legend('bottomright',
         legend = c('LTN (lambda=10)', 'DirFactor (r=2)','DirFactor (r=5)', 'MaAsLin2 (default)'),
         fill=c('black', '#e41a1c', '#48dc48', '#4b99ae'))
# abline(v = 0.05)
# abline(v = 0.01)
}


dev.off()