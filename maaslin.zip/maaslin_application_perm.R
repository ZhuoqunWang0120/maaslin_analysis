#!/usr/bin/env Rscript

library(Maaslin2)

rm(list = ls())
ps = readRDS("ps_otu_100.rds")
input_data = data.frame(otu_table(ps)) # taxa are columns
covariates = c("Case_Control", "post_seroconversion", "Age_at_Collection", "Country", "Gender",
"BF", "Solid_Food", "Eggs", "Fish", "Soy_Prod", "Rye", "Barley", "Buckwheat_Millet")
sample_data = data.frame(sample_data(ps))[,c(covariates, "Subject_ID")]
sample_data$log_age = log(sample_data$Age_at_Collection)
sample_data$Age_at_Collection = NULL
fixed_effects = gsub("Age_at_Collection", "log_age", covariates)

for (within_ind in c(1, 0)){
for (seed in 1:500){
    Xtest = matrix(sample_data$post_seroconversion, ncol = 1)
    grouplabel = sample_data$Subject_ID
    set.seed(seed)
    # shuffle Xtest
    if (within_ind == 0){
        Xtest = matrix(Xtest[sample(1:nrow(Xtest),nrow(Xtest),replace = F),],ncol = 1)
  }else{
    for (g in unlist(unique(grouplabel))){
      xg = Xtest[grouplabel == g,]
      Xtest[grouplabel == g,] = xg[sample(1:sum(grouplabel == g), sum(grouplabel == g), F)]
    }
  }
  output_dir = paste0("default_perm/seed", seed, "within", within_ind)
  system(paste0("mkdir -p ", output_dir))
  sample_data$post_seroconversion = as.vector(Xtest)
  saveRDS(sample_data, paste0(output_dir, "/shuffled_sampledata.rds"))
  test_fit = Maaslin2(input_data = input_data,
input_metadata = sample_data, 
output = output_dir, 
fixed_effects = fixed_effects,
random_effects = "Subject_ID",
plot_heatmap = F,
plot_scatter = F)
}
}


# collect results
# min(pval)
for (within_ind in 0:1){
    cat("within_ind", within_ind, "\n")
    pval_null = sapply(1:500, function(x){
    file = paste0("default_perm/seed", x, "within", within_ind, "/all_results.tsv")
    all_results = read.csv(file, sep = "\t")
    return(min(all_results[all_results$metadata == "post_seroconversion", "pval"]))
})
all_results = read.csv("default_output/all_results.tsv", sep = "\t")
pval_test = min(all_results[all_results$metadata == "post_seroconversion", "pval"])

perm_pval = mean(pval_null <= pval_test)
cat("permutation pvalue: ", perm_pval, "\n")
}

# min(qval)
for (within_ind in 0:1){
    cat("within_ind", within_ind, "\n")
    pval_null = sapply(1:500, function(x){
    file = paste0("default_perm/seed", x, "within", within_ind, "/all_results.tsv")
    all_results = read.csv(file, sep = "\t")
    return(min(all_results[all_results$metadata == "post_seroconversion", "qval"]))
})
all_results = read.csv("default_output/all_results.tsv", sep = "\t")
pval_test = min(all_results[all_results$metadata == "post_seroconversion", "qval"])

perm_pval = mean(pval_null <= pval_test)
cat("permutation pvalue: ", perm_pval, "\n")
}

# pval and qval
p.adjust(all_results$pval, method = "BH") / all_results$qval
